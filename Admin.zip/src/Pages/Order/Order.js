import React from "react";
import "./Order.css";
export function Order() {
  return <div>Order</div>;
}
