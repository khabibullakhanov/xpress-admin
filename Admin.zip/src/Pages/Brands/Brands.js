import React from 'react'

export  function Brands() {
  return (
    <div>Brands</div>
  )
}
