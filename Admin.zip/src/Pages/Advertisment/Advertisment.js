import React from "react";
import { AdvertiseCard } from "../../Components/AdvertiseCard/AdvertiseCard";

export function Advertisment() {
  return <div>
    <AdvertiseCard />
  </div>;
}
