import React from 'react'

export function NotFounded() {
    return (
        <div>NotFounded </div>
    )
}
